package com.krypturg.model;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
//import javax.persistence.Query;
import java.util.List;

import javax.persistence.NoResultException;

import com.krypturg.Entities.Address;
import com.krypturg.Entities.AdminLogin;
import com.krypturg.Entities.Cart;
import com.krypturg.Entities.Category;
import com.krypturg.Entities.Enquiry;
import com.krypturg.Entities.Order;
import com.krypturg.Entities.Product;
import com.krypturg.Entities.User;

public class DAO {

    private SessionFactory sessionFactory;

    public DAO(SessionFactory sessionFactory) {
        super();
        this.sessionFactory = sessionFactory;
    }

    public boolean saveUser(User user) {
        boolean success = false;
        Session session = null;
        Transaction transaction = null;

        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();
            session.persist(user);
            transaction.commit();
            success = true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }

        return success;
    }

    public void addEnquiry(String name, String phone) {
        Session session = null;
        Transaction transaction = null;

        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();

            Enquiry enquiry = new Enquiry();
            enquiry.setName(name);
            enquiry.setPhone(phone);
            enquiry.setStatus("Pending");

            session.persist(enquiry);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    public String adminLogin(String id, String password) {
        try (Session session = sessionFactory.openSession()) {
            Query<AdminLogin> query = session.createQuery("FROM AdminLogin WHERE id = :id AND password = :password", AdminLogin.class);
            query.setParameter("id", id);
            query.setParameter("password", password);
            List<AdminLogin> results = query.getResultList();
            if (!results.isEmpty()) {
                return results.get(0).getName();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<HashMap<String, Object>> getAllEnquiries() {
        List<HashMap<String, Object>> enquiries = new ArrayList<>();
        try (Session session = sessionFactory.openSession()) {
            @SuppressWarnings("deprecation")
			List<Object[]> results = session.createNativeQuery("select * from enquiries order by id DESC").getResultList();
            for (Object[] row : results) {
                HashMap<String, Object> enquiry = new HashMap<>();
                enquiry.put("id", row[0]);
                enquiry.put("name", row[1]);
                enquiry.put("phone", row[2]);
                enquiry.put("e_date", row[3]);
                enquiry.put("status", row[4]);
                enquiries.add(enquiry);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return enquiries;
    }
    public void changeEnquiryStatus(int id) throws SQLException {
        Session session = null;
        Transaction transaction = null;

        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();

            @SuppressWarnings("deprecation")
			Query query = session.createQuery("UPDATE Enquiry SET status = 'Done' WHERE id = :id");
            query.setParameter("id", id);
            query.executeUpdate();
            
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    public String addCategory(String name) throws SQLException {
        Session session = null;
        Transaction transaction = null;
        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();

            Category category = new Category();
            category.setName(name);

            session.persist(category);

            transaction.commit();
            return "Success";
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            return "Failed! (Already Exist!)";
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    public List<String> getAllCategory() throws SQLException {
        Session session = null;
        try {
            session = sessionFactory.openSession();
            return session.createQuery("SELECT c.name FROM Category c", String.class).getResultList();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    public void deleteCategory(String name) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Query query = session.createQuery("DELETE FROM Category WHERE name = :name");
            query.setParameter("name", name);
            int rowsAffected = query.executeUpdate();
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public String addProduct(Product product) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.persist(product);
            transaction.commit();
            return "Success";
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return "Failed";
        }
    }

    public void closeSession() {
        sessionFactory.close();
    }
    
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            products = session.createQuery("FROM Product ORDER BY category DESC", Product.class).list();
            transaction.commit();
        } catch (RuntimeException e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            throw e;
        } finally {
            session.close();
        }
        return products;
    }
    public byte[] getProductImage(String name) throws SQLException {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Query<Product> query = session.createQuery("SELECT p FROM Product p WHERE p.name = :name", Product.class);
            query.setParameter("name", name.trim());
            Product product = query.uniqueResult();
            byte[] image = product != null ? product.getImage() : null;
            transaction.commit();
            return image;
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("Error retrieving product image", e);
        }
    }
    public void deleteProduct(String name) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Query<Product> query = session.createQuery("DELETE FROM Product p WHERE p.name = :name");
            query.setParameter("name", name);
            query.executeUpdate();
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            // You can handle the exception as per your application's requirements
        }
    }
    public String userLogin(String email, String password) throws SQLException {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Query<User> query = session.createQuery("FROM User WHERE email = :email AND password = :password", User.class);
            query.setParameter("email", email);
            query.setParameter("password", password);
            User user;
            try {
                user = query.getSingleResult();
            } catch (NoResultException e) {
                user = null;
            }
            transaction.commit();
            return user != null ? user.getName() : null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("Error occurred while logging in", e);
        }
    }
    
    public List<HashMap<String, Object>> getProductsLikeName(String name) {
        List<HashMap<String, Object>> products = new ArrayList<>();
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Query query = session.createQuery("FROM Product WHERE name LIKE :name ORDER BY category DESC");
            query.setParameter("name", "%" + name + "%");
            List<Product> productList = query.list();
            for (Product product : productList) {
                HashMap<String, Object> productMap = new HashMap<>();
                productMap.put("name", product.getName());
                productMap.put("price", product.getPrice());
                productMap.put("cname", product.getCname());
                productMap.put("category", product.getCategory());
                productMap.put("description", product.getDescription());
                productMap.put("qty", product.getQty());
                products.add(productMap);
            }
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return products;
    }
    public void addToCart(String email, String name) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Query query = session.createQuery("FROM Cart WHERE email = :email");
            query.setParameter("email", email);
            List<Cart> carts = query.getResultList();
            if (!carts.isEmpty()) {
                Cart cart = carts.get(0);
                String items = cart.getItems();
                items += "," + name;
                cart.setItems(items);
                session.update(cart);
            } else {
                Cart cart = new Cart();
                cart.setEmail(email);
                cart.setItems(name);
                session.persist(cart);
            }
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public int countCart(String email) {
        Session session = null;
        try {
            session = sessionFactory.openSession();
            String jpql = "SELECT c.items FROM Cart c WHERE c.email = :email";
            Query<String> query = session.createQuery(jpql, String.class);
            query.setParameter("email", email);
            String items = query.uniqueResult();
            if (items != null) {
                String[] itemList = items.split(",");
                return itemList.length;
            } else {
                return 0;
            }
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    public String[] getAllCartItemsByEmail(String email) {
        try (Session session = sessionFactory.openSession()) {
            Cart cart = session.createQuery("FROM Cart WHERE email = :email", Cart.class)
                               .setParameter("email", email)
                               .uniqueResult();
            if (cart != null) {
                return cart.getItems().split(",");
            } else {
                return null;
            }
        }
    }
    public int getItemPrice(String name) {
        try (Session session = sessionFactory.openSession()) {
            Product product = session.createQuery("FROM Product WHERE name = :name", Product.class)
                                    .setParameter("name", name)
                                    .uniqueResult();
            if (product != null) {
                return product.getPrice();
            } else {
                return 0;
            }
        }
    }
    @SuppressWarnings("deprecation")
    public void removeFromCart(String email, String name) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Cart cart = session.get(Cart.class, email);
            if (cart != null) {
                String items = cart.getItems();
                List<String> itemList = new ArrayList<>(Arrays.asList(items.split(",")));
                itemList.remove(name);
                items = String.join(",", itemList);
                cart.setItems(items);
                session.update(cart);
            }
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<String> getProductByCategory(String category) {
        Session session = null;
        try {
            session = sessionFactory.openSession();
            String jpql = "SELECT p.name FROM Product p WHERE p.category = :category";
            Query query = session.createQuery(jpql);
            query.setParameter("category", category);
            List<String> productList = query.getResultList();
            return new ArrayList<>(productList);
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    public List<String> getAddressByEmail(String email) {
        List<String> addresses = new ArrayList<>();
        try (Session session = sessionFactory.openSession()) {
            String hql = "SELECT a.address FROM Address a WHERE a.email = :email";
            Query<String> query = session.createQuery(hql, String.class);
            query.setParameter("email", email);
            addresses = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return addresses;
    }
    public void addAddress(String email, String address) {
        Session session = null;
        Transaction transaction = null;
        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();

            Address newAddress = new Address();
            newAddress.setEmail(email);
            newAddress.setAddress(address);

            session.persist(newAddress);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    @SuppressWarnings("deprecation")
	public void orderPlaced(String email, String address) throws SQLException {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            String[] items = getAllCartItemsByEmail(email);
            StringBuilder orderItems = new StringBuilder();
            int total = 0;
            for (String item : items) {
                int price = getItemPrice(item);
                total += price;
                orderItems.append(",").append(item).append("-").append(price);
            }
            String formattedOrderItems = orderItems.substring(1);

            Order order = new Order();
            order.setEmail(email);
            order.setAddress(address);
            order.setTotal(total);
            order.setItems(formattedOrderItems);
            order.setStatus("Pending");

            session.persist(order);

            session.createQuery("delete from Cart where email = :email")
                    .setParameter("email", email)
                    .executeUpdate();

         
            session.createQuery("update Product set qty = qty - 1 where name in :items")
                     .setParameter("items", items)
                     .executeUpdate();
           

            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public List<HashMap<String, Object>> getOrdersByEmail(String email) {
        List<HashMap<String, Object>> orders = new ArrayList<>();
        try (Session session = sessionFactory.openSession()) {
            Query<Order> query = session.createQuery("FROM Order WHERE email = :email ORDER BY order_Date DESC", Order.class);
            query.setParameter("email", email);
            List<Order> orderEntities = query.getResultList();
            for (Order orderEntity : orderEntities) {
                orders.add(orderEntityToHashMap(orderEntity));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orders;
    }

    public List<HashMap<String, Object>> getOrders() {
        List<HashMap<String, Object>> orders = new ArrayList<>();
        try (Session session = sessionFactory.openSession()) {
            List<Object[]> results = session.createNativeQuery("SELECT * FROM orders ORDER BY order_date DESC").list();
            for (Object[] row : results) {
                HashMap<String, Object> order = new HashMap<>();
                order.put("id", row[0]);
                order.put("email", row[1]);
                order.put("address", row[2]);
                order.put("items", row[3]);
                order.put("total", row[4]);
                order.put("status", row[5]);
                order.put("order_date", row[6]);
                orders.add(order);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orders;
    }

    private HashMap<String, Object> orderEntityToHashMap(Order orderEntity) {
        HashMap<String, Object> order = new HashMap<>();
        order.put("id", orderEntity.getId());
        order.put("email", orderEntity.getEmail());
        order.put("address", orderEntity.getAddress());
        order.put("items", orderEntity.getItems());
        order.put("total", orderEntity.getTotal());
        order.put("status", orderEntity.getStatus());
        order.put("order_Date", orderEntity.getOrder_Date());
        return order;
    }
    public void changeOrderStatus(int id, String status) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Query<Order> query = session.createQuery("UPDATE Order SET status = :status WHERE id = :id");
            query.setParameter("status", status);
            query.setParameter("id", id);
            query.executeUpdate();
            transaction.commit();

            if (status.equalsIgnoreCase("Canceled") || status.equalsIgnoreCase("Rejected")) {
                Order order = session.get(Order.class, id);
                String items = order.getItems();
                String[] itemArray = items.split(",");
                for (String item : itemArray) {
                    String[] parts = item.split("-");
                    String itemName = parts[0];
                    int quantity = Integer.parseInt(parts[1]);
                    Query updateQuery = session.createQuery("UPDATE Product SET qty = qty + :quantity WHERE name = :name");
                    updateQuery.setParameter("quantity", quantity);
                    updateQuery.setParameter("name", itemName);
                    updateQuery.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    



}
