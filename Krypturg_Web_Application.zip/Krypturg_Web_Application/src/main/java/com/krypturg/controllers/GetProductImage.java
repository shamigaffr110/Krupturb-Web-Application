package com.krypturg.controllers;

import com.krypturg.model.DAO;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/GetProductImage")
public class GetProductImage extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DAO productDAO;

    public void init() throws ServletException {
        super.init();
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        productDAO = new DAO(sessionFactory);
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String name = request.getParameter("name");
            byte[] image = productDAO.getProductImage(name);
            if (image != null) {
                response.getOutputStream().write(image);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    public void destroy() {
        super.destroy();
        productDAO = null;
    }
}
