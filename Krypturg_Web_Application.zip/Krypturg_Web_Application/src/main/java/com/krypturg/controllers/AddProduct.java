package com.krypturg.controllers;

import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import org.hibernate.SessionFactory;

import com.krypturg.Entities.Product;
import com.krypturg.conn.HibernateUtil;
import com.krypturg.model.DAO;

@WebServlet("/AddProduct")
@MultipartConfig
public class AddProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private DAO dao;

    @Override
    public void init() throws ServletException {
        super.init();
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        dao = new DAO(sessionFactory);
    }

    @Override
    public void destroy() {
        super.destroy();
        dao.closeSession();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward the request to the form page
        request.getRequestDispatcher("AddProduct.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Retrieve form data
            String name = request.getParameter("name");
            int price = Integer.parseInt(request.getParameter("price"));
            String cname = request.getParameter("cname");
            String category = request.getParameter("category");
            String description = request.getParameter("description");
            int qty = Integer.parseInt(request.getParameter("qty"));
            Part imagePart = request.getPart("image");
            
            // Convert image input stream to byte array
            InputStream imageStream = imagePart.getInputStream();
            byte[] imageBytes = imageStream.readAllBytes();
            
            // Create Product object
            Product product = new Product(name.trim(), price, cname, category, description, qty, imageBytes);
            
            // Add product to database
            String result = dao.addProduct(product);
            
            // Set result message in session
            HttpSession session = request.getSession();
            session.setAttribute("msg", result);
            
            // Redirect to Products.jsp
            response.sendRedirect("Products.jsp");
            
        } catch (Exception ex) {
            // Handle any exceptions
            ex.printStackTrace();
            response.sendRedirect("ExpPage.jsp");
        }
    }
}
