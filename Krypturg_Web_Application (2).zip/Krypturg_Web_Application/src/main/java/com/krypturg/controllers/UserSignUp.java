package com.krypturg.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;

import com.krypturg.Entities.User;
import com.krypturg.conn.HibernateUtil;
import com.krypturg.model.DAO;

import jakarta.inject.Inject;

@WebServlet("/UserSignUp")
public class UserSignUp extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Inject
    private DAO dao;

    @Override
    public void init() throws ServletException {
        super.init();
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        dao = new DAO(sessionFactory); // Initialize the dao object with the sessionFactory
    }




    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handling GET requests
        // Here, you might want to redirect users or show them a sign-up form
        // For simplicity, let's redirect them to the sign-up page
        response.sendRedirect("user.jsp");
    }

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handling POST requests
    	 HttpSession session = request.getSession();
        try {
            String uid = request.getParameter("uid");
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            User user = new User(uid, email, name, phone, password);
            System.out.println(user);

            boolean savedSuccessfully = dao.saveUser(user);
            if (savedSuccessfully) {
                String result = "User Registered Successfully";
                session.setAttribute("msg", result);
                response.sendRedirect("UserHome.jsp");
                // Redirect to a success page or do something else
            }else {
            	String result = "Something went Wrong!";
                session.setAttribute("msg", result);
                response.sendRedirect("user.jsp");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("ExpPage.jsp");
        }
    }
}







