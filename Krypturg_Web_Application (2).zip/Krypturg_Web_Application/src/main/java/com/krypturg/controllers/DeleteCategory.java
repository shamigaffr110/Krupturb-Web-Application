package com.krypturg.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.SessionFactory;

import com.krypturg.conn.HibernateUtil;
import com.krypturg.model.DAO;

@WebServlet("/DeleteCategory")
public class DeleteCategory extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DAO dao;
    private SessionFactory sessionFactory;

    @Override
    public void init() throws ServletException {
        super.init();
        sessionFactory = HibernateUtil.getSessionFactory();
        dao = new DAO(sessionFactory);
    }

    @Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String name = request.getParameter("name");
            dao.deleteCategory(name);

            request.getSession().setAttribute("msg", "Category Deleted!");
            response.sendRedirect("Products.jsp");
        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("ExpPage.jsp");
        }
    }

    @Override
    public void destroy() {
        super.destroy();
        sessionFactory.close();
    }
}
