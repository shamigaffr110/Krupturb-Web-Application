package com.krypturg.conn;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            // Create the SessionFactory from hibernate.cfg.xml
            return new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        } catch (Throwable ex) {
            // Handle initialization errors
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
















//package com.krypturg.conn;
//
//import java.util.Properties;
//
//import org.hibernate.SessionFactory;
//import org.hibernate.cfg.Configuration;
//import org.hibernate.boot.registry.StandardServiceRegistry;
//import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
//
//import com.krypturg.Entities.User;
//
//public class HibernateUtil {
//    private static SessionFactory sessionFactory;
//
//    public static SessionFactory getSessionFactory() {
//        if (sessionFactory == null) {
//            Configuration configuration = new Configuration();
//            Properties properties = new Properties();
//            properties.put("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver");
//            properties.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/krypturg_web_application");
//            properties.put("hibernate.connection.username", "root");
//            properties.put("hibernate.connection.password", "Rochak3803#");
//            properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL8Dialect");
//            properties.put("hibernate.hbm2ddl.auto", "update");
//            properties.put("hibernate.show_sql", "true");
//
//            configuration.setProperties(properties);
//            configuration.addAnnotatedClass(User.class);
//
//            StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
//                    .applySettings(configuration.getProperties()).build();
//            sessionFactory = configuration.buildSessionFactory(standardRegistry);
//        }
//        return sessionFactory;
//    }
//}
